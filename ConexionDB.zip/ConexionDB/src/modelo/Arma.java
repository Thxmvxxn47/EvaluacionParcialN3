/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

/**
 *
 * @author pc gigateck
 */
public class Arma {
    private int idArma;
    private String nombre;
    private double precision;

    public Arma() {}

    public Arma(String nombre, double precision) {
        this.nombre = nombre;
        this.precision = precision;
    }

    public int getIdArma() { return idArma; }
    public void setIdArma(int idArma) { this.idArma = idArma; }

    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }

    public double getPrecision() { return precision; }
    public void setPrecision(double precision) { this.precision = precision; }
}

    

