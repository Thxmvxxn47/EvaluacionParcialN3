/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package modelo;
import java.sql.Connection;
import java.sql.DriverManager;
/**
 *
 * @author pc gigateck
 */
public class ConexionDB {

    public static void main(String[] args) {
        Connection conexion = null;
        try {
        
        Class.forName("com.mysql.cj.jdbc.Driver");
        
        conexion = DriverManager.getConnection("jdbc:mysql://localhost:3306/guardianes_reino","root","");
        System.out.println("Coneccion exitosa");
    } catch(Exception ex) {
        System.out.println(ex.getMessage());
    }
        
        
    }

    public Connection getConnection() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    }
    

   
    

