/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;
import java.sql.*;
import java.util.ArrayList;

/**
 *
 * @author pc gigateck
 */
public class ArmaDao {
     Conexion con = new Conexion();
    Connection cn;
    PreparedStatement ps;
    ResultSet rs;

    public boolean agregar(Arma a){
        String sql = "INSERT INTO arma(nombre, precision) VALUES (?, ?)";
        try {
            cn = con.conectar();
            ps = cn.prepareStatement(sql);
            ps.setString(1, a.getNombre());
            ps.setDouble(2, a.getPrecision());
            ps.execute();
            return true;
        } catch(Exception e){
            System.out.println(e.getMessage());
            return false;
        }
    }

    public ArrayList<Arma> listar(){
        ArrayList<Arma> lista = new ArrayList<>();
        String sql = "SELECT * FROM arma";

        try {
            cn = con.conectar();
            ps = cn.prepareStatement(sql);
            rs = ps.executeQuery();

            while(rs.next()){
                Arma a = new Arma();
                a.setIdArma(rs.getInt("idArma"));
                a.setNombre(rs.getString("nombre"));
                a.setPrecision(rs.getDouble("precision"));
                lista.add(a);
            }
        } catch (Exception e){
            System.out.println(e.getMessage());
        }
        return lista;
    }

    private static class Conexion {

        public Conexion() {
        }

        private Connection conectar() {
            throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
        }
    }
}
    
    
