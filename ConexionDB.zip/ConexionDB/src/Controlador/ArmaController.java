/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlador;
import Vista.FrmVista;
import java.util.ArrayList;
import javax.swing.table.DefaultTableModel;
import modelo.Arma;
import modelo.ArmaDao;


public class ArmaController {

    private final FrmVista vista;
    private ArmaDao dao = new ArmaDao();

    public ArmaController(FrmVista vista) {
        this.vista = vista;

     
        this.vista.btnGuardar.addActionListener(e -> guardar());
        this.vista.btnListar.addActionListener(e -> listar());
        this.vista.btnLimpiar.addActionListener(e -> limpiar());

 
        listar();
    }

   
    private void guardar() {
        String nombre = vista.txtNombre.getText();
        String precStr = vista.txtPrecision.getText();

        if (nombre.isEmpty() || precStr.isEmpty()) {
            javax.swing.JOptionPane.showMessageDialog(vista, "Complete todos los campos.");
            return;
        }

        double prec;
        try {
            prec = Double.parseDouble(precStr);
        } catch (NumberFormatException ex) {
            javax.swing.JOptionPane.showMessageDialog(vista, "La precisión debe ser un número (0 a 1).");
            return;
        }

        if (prec < 0 || prec > 1) {
            javax.swing.JOptionPane.showMessageDialog(vista, "La precisión debe estar entre 0 y 1.");
            return;
        }

        Arma a = new Arma(nombre, prec);

        if (dao.agregar(a)) {
            javax.swing.JOptionPane.showMessageDialog(vista, "Arma registrada correctamente.");
            listar();   
            limpiar();  
        } else {
            javax.swing.JOptionPane.showMessageDialog(vista, "Error al registrar el arma.");
        }
    }


    public void listar() {
        ArrayList<Arma> lista = dao.listar();
        DefaultTableModel model = (DefaultTableModel) vista.tablaArmas.getModel();
        model.setRowCount(0); // limpiar filas

        for (Arma a : lista) {
            model.addRow(new Object[]{
                a.getIdArma(),
                a.getNombre(),
                a.getPrecision()
            });
        }
    }


    private void limpiar() {
        vista.txtNombre.setText("");
        vista.txtPrecision.setText("");
        vista.txtNombre.requestFocus();
    }

    private static class FrmVista {

        public FrmVista() {
        }
    }
}

